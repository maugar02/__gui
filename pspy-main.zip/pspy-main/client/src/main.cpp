#include <iostream>
#include <pspyk.hpp>

int main()
{
	pspy::DeviceScanner ds;

	while(1) {

		auto klist = ds.getKeyboardDevices();
		auto mlist = ds.getMouseDevices();

		std::cout << "\tPeripheral SPY." << std::endl << std::endl;
		
		if(ds.isKAlert())
		{
			std::cout << "El teclado esta desconectado." << std::endl;
		}

		if(ds.isMAlert())
		{
			std::cout << "El mouse esta desconectado." << std::endl;
		}

		if(!ds.isKAlert() && !ds.isMAlert())
		{
			std::cout << "Detectados " << klist.getCount() << " teclados." << std::endl << std::endl;
			for(int a(0); a < klist.getCount(); a++) {
				std::cout << a << "] ID: " << klist.getDevice(a).getName() << std::endl;
			}
			std::cout << "..." << std::endl;
			std::cout << "Detectados " << mlist.getCount() << " mouses." << std::endl << std::endl;
			for(int a(0); a < mlist.getCount(); a++) {
				std::cout << a << "] ID: " << mlist.getDevice(a).getName() << std::endl;
			}

		}
		
		if(!ds.NotifyEvent()) {
			system("cls");
			std::cout << "Problema al obtener información acerca de los dispositivos." << std::endl;
		}

		Sleep(1936);
		system("cls");
	}

	return 0;
}