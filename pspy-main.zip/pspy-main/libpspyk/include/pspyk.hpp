#ifndef PSPYK_HPP
#define PSPYK_HPP

/* Detectar la plataforma */
#if defined _WIN32 || defined _WIN64
#  define PSPYK_WINDOWS
#else
#  error "El sistema operativo no es compatible"
#endif

#if defined PSPYK_WINDOWS && defined __PSPYK_BUILD__
#  define PSPYK_EXPORTS __declspec(dllexport)
#elif defined PSPYK_WINDOWS
#  define PSPYK_EXPORTS __declspec(dllimport)
#endif

#include <windows.h>
#include <string>
#include <vector>

using uint = unsigned int;

namespace pspy{

	class PSPYK_EXPORTS MouseDev final{
	private:
		std::string name;
		uint id;
		bool connected;
	public:
		MouseDev(std::string n, bool con);

		std::string getName();
		uint getID();
		bool isConnected();
		void clear();
	};

	class PSPYK_EXPORTS KeyboardDev final{
	private:
		std::string name;
		bool connected;
	public:
		KeyboardDev(std::string n, bool con);

		std::string getName();
		bool isConnected();
		void clear();
	};

	class PSPYK_EXPORTS MouseDevList final {
	private:
		std::vector<MouseDev> _devices;
	public:
		MouseDevList();
		uint getCount();
		void clear();

		// From 0
		MouseDev getDevice(const uint index);
		bool AddMouseDev(MouseDev const& dev);

	};

	class PSPYK_EXPORTS KeyboardDevList final {
	private:
		std::vector<KeyboardDev> _devices;
	public:
		KeyboardDevList();
		uint getCount();
		void clear();
		// From 0
		KeyboardDev getDevice(const uint index);
		bool AddKeyboardDev(KeyboardDev const& dev);

	};

	class PSPYK_EXPORTS DeviceScanner final {

	private:

		MouseDevList mouse_list;
		KeyboardDevList keyboard_list;

		bool mAlert;
		bool kAlert;

	public:

		DeviceScanner();

		void Clear();
		bool Now();
		bool NotifyEvent();
		uint getDevicesCount();

		MouseDevList getMouseDevices();
		KeyboardDevList getKeyboardDevices();

		bool isKAlert();
		bool isMAlert();
	};

}

#endif