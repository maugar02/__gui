#include <pspyk.hpp>

namespace pspy {

	MouseDev::MouseDev(std::string n, bool con) : name{n}, id{0}, connected{con}
	{

	}

	void MouseDev::clear()
	{
		this->name = "";
		this->id = 0;
		this->connected = false;
	}

	std::string MouseDev::getName(){
		return this->name;
	}

	uint MouseDev::getID()
	{
		return this->id;
	}

	bool MouseDev::isConnected()
	{
		return this->connected;
	}

	KeyboardDev::KeyboardDev(std::string n, bool con) : name{n}, connected{con}
	{

	}

	void KeyboardDev::clear()
	{
		this->name = "";
		this->connected = false;
	}

	std::string KeyboardDev::getName(){
		return this->name;
	}

	bool KeyboardDev::isConnected()
	{
		return this->connected;
	}

	KeyboardDevList::KeyboardDevList(){

	}

	uint KeyboardDevList::getCount(){
		return static_cast<uint>(this->_devices.size());
	}

	KeyboardDev KeyboardDevList::getDevice(const uint index)
	{
		return this->_devices.at(index);
	}

	bool KeyboardDevList::AddKeyboardDev(KeyboardDev const& dev)
	{
		this->_devices.push_back(dev);
	}

	void KeyboardDevList::clear()
	{
		return this->_devices.clear();
	}

	MouseDevList::MouseDevList(){

	}

	uint MouseDevList::getCount(){
		return static_cast<uint>(this->_devices.size());
	}

	MouseDev MouseDevList::getDevice(const uint index)
	{
		return this->_devices.at(index);
	}

	void MouseDevList::clear()
	{
		return this->_devices.clear();
	}

	bool MouseDevList::AddMouseDev(MouseDev const& dev)
	{
		this->_devices.push_back(dev);
	}

	// Clase principal
	DeviceScanner::DeviceScanner() : kAlert{false}, mAlert{false}
	{
		this->Now();
	}

	bool DeviceScanner::Now()
	{

		UINT DevicesCount(0U);

		// Verificamos si hay dispositivos conectados
		GetRawInputDeviceList(NULL, &DevicesCount, sizeof(RAWINPUTDEVICELIST));

		if(DevicesCount < 1) {

			// No hay ningún dispositivo conectado
			this->Clear();
			this->mAlert = true;
			this->kAlert = true;
			return false;
		}

		// Si hay dipositivos procedemos a escanearlos
		PRAWINPUTDEVICELIST pRIDL;

		pRIDL = new RAWINPUTDEVICELIST[sizeof(RAWINPUTDEVICELIST)*DevicesCount];

		if(pRIDL == nullptr) {

			// No se ha podido reservar memoria
			delete[] pRIDL;
			return false;
		}

		int nresult(0);

		// Procedemos a obtener información acerda de los dispositivos
		nresult = GetRawInputDeviceList(pRIDL, &DevicesCount, sizeof(RAWINPUTDEVICELIST));

		if(nresult < 1) {
			// No se pudo obtener información
			delete[] pRIDL;
			return false;
		}


		// Recorremos la lista de dispositivos
		for(auto i(0U); i < DevicesCount; i++) {

			TCHAR *name_str(nullptr);
			UINT name_len(0U);
			UINT buffer_len(0U);
			RID_DEVICE_INFO rdiDeviceInfo;
			rdiDeviceInfo.cbSize = sizeof(RID_DEVICE_INFO);
			buffer_len = rdiDeviceInfo.cbSize;

			// Intentamos obtener el nombre
			GetRawInputDeviceInfo(pRIDL[i].hDevice, RIDI_DEVICENAME, NULL, &name_len);

			name_str = new TCHAR[name_len + 1];

			if(name_str  == nullptr) {
				// No se pudo reservar memoria
				delete[] pRIDL;
				delete[] name_str;

				return false;
			}

			nresult = GetRawInputDeviceInfo(pRIDL[i].hDevice, RIDI_DEVICENAME, name_str, &name_len);
			if(nresult < 0) {
				// No se pudo obtener información del dispositivo
				delete[] name_str;

				continue;
			}

			// Obtenemos información completa acerca del dispositivo
			nresult = GetRawInputDeviceInfo(pRIDL[i].hDevice, RIDI_DEVICEINFO, &rdiDeviceInfo, &buffer_len);
			if(nresult < 0) {
				// No se pudo obtener información del dispositivo
				delete[] name_str;

				continue;
			}

			// Procesamos la información

			/* Filtramos por tipo de dispositivo */
			if(rdiDeviceInfo.dwType == RIM_TYPEMOUSE) {

				MouseDev temp_dev(std::string(name_str), 1);
				this->mouse_list.AddMouseDev(temp_dev);

			}else if(rdiDeviceInfo.dwType == RIM_TYPEKEYBOARD) {

				KeyboardDev temp_dev(std::string(name_str), 1);
				this->keyboard_list.AddKeyboardDev(temp_dev);
			}

			delete[] name_str;
		}

		// asd
		this->mAlert = false;
		this->kAlert = false;

		if(this->mouse_list.getCount() < 1){
			this->mAlert = true;
		}
		if(this->keyboard_list.getCount() < 1){
			this->kAlert = true;
		}

		delete[] pRIDL;
		return true;
	}

	void DeviceScanner::Clear() {
		this->mouse_list.clear();
		this->keyboard_list.clear();
	}

	bool DeviceScanner::NotifyEvent() {

		this->Clear();
		this->Now();

		return true;
	}

	uint DeviceScanner::getDevicesCount() {
		return (this->mouse_list.getCount() + this->keyboard_list.getCount());
	}

	MouseDevList DeviceScanner::getMouseDevices() {
		return this->mouse_list;
	}

	KeyboardDevList DeviceScanner::getKeyboardDevices() {
		return this->keyboard_list;
	}

	bool DeviceScanner::isKAlert() {
		return this->kAlert;
	}

	bool DeviceScanner::isMAlert() {
		return this->mAlert;
	}
}